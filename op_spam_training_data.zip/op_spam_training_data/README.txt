This package includes material excerpted from the Deceptive Opinion
Spam Corpus v1.4, and is intended for use in a homework exercise in
the course CSCI 544 Applied Natural Language Processing at USC.

Other uses are permitted (see license), but users are encouraged to
refer back to the original corpus.
